
# Assignment 01
# c0837117 - Asif Mahmud
# Question 01
# Date of submission: 2021-09-19

if __name__ == '__main__':
    print('Q1.b')
    print('Q2.a')
    print('Q3.e')
    print('Q4.b')
    print('Q5.c')
    print('Q6.a')
    print('Q7.c')
    print('Q8.b')
    print('Q9.a')
    print('Q10.a')
    print('Q11.d')
    print('Q12.b')
    print('Q13.c')
    print('Q14.b')
    print('Q15.c')
    print('Q16.a')
    print('Q17.b')
    print('Q18.d')
    print('Q19.b')
    print('Q20.b')
    print('Q21.c')
    print('Q22.a')
    print('Q23.d')
    print('Q24.a')
    print('Q25.b')