
# Assignment 01
# c0837117 - Asif Mahmud
# Question 02
# Date of submission: 2021-09-19

if __name__ == '__main__':
    print(' (\___/)')
    print('  (=.=)')
    print('(")__(")')
    print('Rabbit')
    print()
    print('  @..@')
    print(' (----)')
    print('(>____<)')
    print(' ^^ ^^')
    print('Frog')
    print()
    print(' |  ||')
    print(' \\\()//')
    print('//(__)\\\\')
    print('||    ||')
    print('Spider')
    
    
    